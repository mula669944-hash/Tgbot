import telebot
import requests
import json
import re
from urllib.parse import urlparse

# Telegram Bot Token
BOT_TOKEN = "8747303635:AAE4Ma1V3opCg_FkVpwtwn1PMlbmFmKRF7E"

# Firebase Realtime Database URL
FIREBASE_DB_URL = "https://golpo-910cc-default-rtdb.firebaseio.com/posts.json"

bot = telebot.TeleBot(BOT_TOKEN)

def is_valid_url(url):
    regex = re.compile(
        r'^(?:http|ftp)s?://'
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'
        r'localhost|'
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
        r'(?::\d+)?'
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
    return re.match(regex, url) is not None

def extract_first_url(text):
    """যেকোনো টেক্সট বা পোস্ট থেকে প্রথম লিংকটি খুঁজে বের করার ফাংশন"""
    if not text:
        return None
    # মেসেজের ভেতরে থাকা প্রথম URL ম্যাচ করানো
    match = re.search(r'(https?://[^\s]+)', text)
    if match:
        # লিংকের শেষে ভুলবশত কোনো ফুলস্টপ, কমা বা ব্র্যাকেট থাকলে তা বাদ দেওয়া
        return match.group(1).rstrip('.,!?:;()[]{}')
    return None

# যেসব ফালতু নাম কখনোই টাইটেল হতে পারে না
INVALID_TITLES = [
    "home", "প্রথম পাতা", "হোম", "index", "skip to content", "untitled", 
    "welcome", "archive", "category", "menu", "navigation", "error", "404"
]

def clean_universal_heading(raw_title, content, url):
    """যেকোনো সাইটের টাইটেলকে সাইটের লেজুর ও বিজ্ঞাপনমুক্ত করার ফাংশন"""
    candidate = raw_title.strip() if raw_title else ""

    # ১. সাইটের লেজুর বা ব্র্যান্ড নাম কেটে ফেলা (যেমন: গল্পের নাম - সাইটের নাম -> গল্পের নাম)
    split_chars = [" - ", " | ", " – ", " — ", " » ", " • ", " :: "]
    for char in split_chars:
        if char in candidate:
            candidate = candidate.split(char)[0].strip()

    # ২. যদি প্রাপ্ত টাইটেলটি বাজে হয় বা সাইটের ডোমেইন নাম হয়, তাহলে কন্টেন্টের প্রথম H1 খোঁজা
    domain = urlparse(url).netloc.lower().replace("www.", "")
    if not candidate or any(bad == candidate.lower() for bad in INVALID_TITLES) or domain in candidate.lower():
        # কন্টেন্ট থেকে প্রথম Markdown হেডিং (# Title) খোঁজা
        h1_match = re.search(r'^#\s+(.+)$', content, re.MULTILINE)
        if h1_match:
            candidate = h1_match.group(1).strip()
            for char in split_chars:
                if char in candidate:
                    candidate = candidate.split(char)[0].strip()

    # ৩. শেষ ভরসা: URL স্লাগ থেকে হেডিং তৈরি করা
    if not candidate or any(bad in candidate.lower() for bad in INVALID_TITLES):
        path = urlparse(url).path.strip('/')
        if path:
            slug = path.split('/')[-1].replace('.html', '').replace('.php', '')
            candidate = slug.replace('-', ' ').replace('_', ' ').strip().title()

    return candidate if candidate else "শিরোনামহীন গল্প"

def clean_universal_details(content, heading):
    """যেকোনো সাইটের গল্প থেকে মেনু, তারিখ, লেখক, ভিউ এবং নিচের আবর্জনা বাদ দেওয়া"""
    lines = content.splitlines()
    clean_lines = []
    story_started = False

    for line in lines:
        l = line.strip()
        if not l:
            continue

        # গল্প শুরু হওয়ার আগের আবর্জনা ফিল্টারিং:
        if not story_started:
            # যদি লাইনটি টাইটেলের সাথে মিলে যায়, স্কিপ
            if heading.lower() in l.lower():
                continue
            # ইমেজ বা লিংক স্কিপ
            if l.startswith('![') or l.startswith('http'):
                continue
            # ছোট মেটাডাটা (যেমন: তারিখ, Author, 👁, সংখ্যা, Share বাটন) স্কিপ
            if len(l) < 45 and (
                re.search(r'\b(by|published|date|views|eye|author|\d{4})\b', l, re.I) or 
                re.match(r'^(👁|\d{1,3}(,\d{3})*|\d+|share)$', l, re.I)
            ):
                continue
            
            # যখনই বাংলা কোনো বাস্তবসম্মত লম্বা লাইন বা বাক্য পাওয়া যাবে, গল্প শুরু!
            if len(l) > 35:
                story_started = True

        # গল্প চলার সময়:
        if story_started:
            # নিচের দিকের সম্পর্কিত পোস্ট, কমেন্ট বক্স ইত্যাদি পেলে সেখানেই শেষ করা
            if re.search(r'^(সম্পর্কিত গল্প|related posts|leave a reply|মন্তব্য করুন|share this|ফেসবুকে শেয়ার)', l, re.I):
                break
            clean_lines.append(line)

    final_text = "\n\n".join(clean_lines) if clean_lines else content

    # অতিরিক্ত মার্কডাউন লিংক/ইমেজ ক্লিন করা
    final_text = re.sub(r'!\[.*?\]\(.*?\)', '', final_text)
    final_text = re.sub(r'\[(.*?)\]\(.*?\)', r'\1', final_text)
    final_text = re.sub(r'\n{3,}', '\n\n', final_text)
    
    return final_text.strip()

def scrape_story(target_url):
    try:
        proxy_url = f"https://r.jina.ai/{target_url}"
        
        # Jina-র কাছে অফিসিয়াল JSON চাওয়া হচ্ছে
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept": "application/json",
            "X-Wait-For": "2",
            "X-No-Cache": "true"
        }

        response = requests.get(proxy_url, headers=headers, timeout=35)
        
        if response.status_code != 200:
            return None, None

        # JSON ডাটা পড়া
        res_data = response.json()
        data = res_data.get("data", {})
        
        raw_title = data.get("title", "")
        raw_content = data.get("content", "")

        if not raw_content:
            return None, None

        # ক্লাউডফ্লেয়ার চেকিং ব্লকে আটকে গেলে বাতিল
        if "checking your browser" in raw_content[:300].lower():
            return None, None

        # ১. ইউনিভার্সাল হেডিং প্রসেসিং
        heading = clean_universal_heading(raw_title, raw_content, target_url)

        # ২. ইউনিভার্সাল গল্পের বডি প্রসেসিং
        details = clean_universal_details(raw_content, heading)

        if heading and details and len(details) > 80:
            return heading, details

        return None, None

    except Exception as e:
        print(f"Universal Scrape Error: {e}")
        return None, None

# Firebase Database-এ আপলোড
def upload_to_firebase(heading, details):
    try:
        payload = {
            "heading": heading,
            "details": details
        }
        response = requests.post(FIREBASE_DB_URL, json=payload, timeout=10)
        if response.status_code == 200:
            return True, response.json().get('name')
        else:
            return False, response.text
    except Exception as e:
        return False, str(e)

# টেলিগ্রাম হ্যান্ডলার
@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "👋 স্বাগতম! যেকোনো ওয়েবসাইটের গল্পের লিংক দিন (বা লিংকসহ পোস্ট পাঠান)। আমি স্বয়ংক্রিয়ভাবে আসল হেডিং ও ফ্রেশ গল্প Firebase-এ সেভ করে দেব।")

# সাধারণ মেসেজ বা ক্যাপশনসহ পোস্ট হ্যান্ডল করবে
@bot.message_handler(func=lambda message: True, content_types=['text', 'photo'])
def handle_message(message):
    # টেক্সট অথবা ক্যাপশন থেকে লেখা নেওয়া
    raw_text = message.text or message.caption or ""
    
    # পোস্ট বা টেক্সটের ভেতর থেকে ১ম লিংকটি খুঁজে বের করা
    url = extract_first_url(raw_text)

    # যদি কোনো লিংক খুঁজে না পাওয়া যায় অথবা লিংকটি সঠিক না হয়
    if not url or not is_valid_url(url):
        bot.reply_to(message, "❌ অনুগ্রহ করে একটি সঠিক লিংক দিন অথবা লিংকযুক্ত পোস্ট পাঠান!")
        return

    status_msg = bot.reply_to(message, f"🔗 লিংক পাওয়া গেছে: `{url}`\n⏳ সাইটের মেটাডাটা ও মূল কনটেন্ট প্রসেস করা হচ্ছে...", parse_mode="Markdown")

    heading, details = scrape_story(url)

    if not heading or not details:
        bot.edit_message_text("❌ দুঃখিত! এই সাইটটি থেকে গল্প বা হেডিং সংগ্রহ করা সম্ভব হয়নি।", 
                              chat_id=message.chat.id, 
                              message_id=status_msg.message_id)
        return

    bot.edit_message_text(f"📖 গল্প উদ্ধার সম্পন্ন!\n\n**Heading:** {heading}\n\nFirebase 'posts'-এ আপলোড হচ্ছে...", 
                          chat_id=message.chat.id, 
                          message_id=status_msg.message_id,
                          parse_mode="Markdown")

    # Firebase আপলোড
    success, db_id = upload_to_firebase(heading, details)

    if success:
        preview = details[:200] + "..." if len(details) > 200 else details
        final_text = (
            f"✅ **সফলভাবে `posts` নোডে সেভ হয়েছে!**\n\n"
            f"📌 **Heading:** {heading}\n"
            f"🔑 **Post ID:** `{db_id}`\n\n"
            f"📝 **Details Preview:**\n{preview}"
        )
        bot.send_message(message.chat.id, final_text, parse_mode="Markdown")
    else:
        bot.send_message(message.chat.id, f"❌ Firebase Error:\n`{db_id}`", parse_mode="Markdown")

if __name__ == "__main2__":
    print("🤖 Universal Story Scraper Bot Running...")
    bot.infinity_polling()